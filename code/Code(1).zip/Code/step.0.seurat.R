setwd("./")
library(dplyr)
library(Seurat)
library(patchwork)

# Load the PBMC dataset
pbmc.data <- Read10X(data.dir = "./GSE104276_all_pfc_2394_UMI_TPM_NOERCC.xls",header = T,sep = "\t",row.names = 1)

# load metadata
meta.data<- read.table("./cell_mapping.txt",header = T,sep = "\t",row.names = 1)

# Initialize the Seurat object with the raw (non-normalized data).
pbmc <- CreateSeuratObject(counts = pbmc.data, project = "pbmc3k", min.cells = 3, min.features = 200,meta.data=meta.data)

pbmc <- NormalizeData(pbmc, normalization.method = "LogNormalize", scale.factor = 10000)
pbmc <- NormalizeData(pbmc)


pbmc <- FindVariableFeatures(pbmc, selection.method = "vst", nfeatures = 2000)
# Identify the 10 most highly variable genes
top10 <- head(VariableFeatures(pbmc), 10)

# plot variable features with and without labels
plot1 <- VariableFeaturePlot(pbmc)
plot2 <- LabelPoints(plot = plot1, points = top10, repel = TRUE)
plot1 + plot2


# Scaling the data
all.genes <- rownames(pbmc)
pbmc <- ScaleData(pbmc, features = all.genes)

# Perform linear dimensional reduction
pbmc <- RunPCA(pbmc, features = VariableFeatures(object = pbmc))
# Examine and visualize PCA results a few different ways
print(pbmc[["pca"]], dims = 1:5, nfeatures = 5)


VizDimLoadings(pbmc, dims = 1:2, reduction = "pca")
DimPlot(pbmc, reduction = "pca")

DimHeatmap(pbmc, dims = 1, cells = 500, balanced = TRUE)
DimHeatmap(pbmc, dims = 1:15, cells = 500, balanced = TRUE)


pbmc <- JackStraw(pbmc, num.replicate = 100)
pbmc <- ScoreJackStraw(pbmc, dims = 1:20)

JackStrawPlot(pbmc, dims = 1:15)
ElbowPlot(pbmc)


###    Cluster the cells   #######
pbmc <- FindNeighbors(pbmc, dims = 1:15)
pbmc <- FindClusters(pbmc, resolution = 0.5)
# Look at cluster IDs of the first 5 cells
head(Idents(pbmc), 5)

pbmc <- RunUMAP(pbmc, dims = 1:10)
pbmc <- RunTSNE(pbmc, dims = 1:10)


DimPlot.do_pre<- DimPlot(pbmc, reduction = "umap",label=T)+ NoLegend()
pdf("Figure.UMAP.Subtype.Without.Annotation.pdf",width = 5,height = 4)
plot(DimPlot.do_pre)
dev.off()

DimPlot(pbmc, reduction = "tsne",label=T,shape.by="cell_types")
saveRDS(pbmc, file = "./pbmc_tutorial.rds")


# Finding differentially expressed features (cluster biomarkers) 
# find markers for every cluster compared to all remaining cells, report only the positive ones
pbmc.markers <- FindAllMarkers(pbmc, only.pos = TRUE, min.pct = 0.25, logfc.threshold = 0.25)
dim(pbmc.markers) # 7461    7
pbmc.markers %>% group_by(cluster) %>% top_n(n = 2, wt = avg_log2FC)
dim(pbmc.markers)
write.table(pbmc.markers,file = "pbmc.markers.DE.txt",col.names = T,row.names = T,sep = "\t",quote = F)


# visulize marker genes 
VlnPlot_Key_Gene<- VlnPlot(pbmc, 
                           features = c("PTPRC","P2RY12",
                                        "PAX6","SFRP1",
                                        "OLIG1","PDGFRA","COL20A1","PMP2",
                                        "NEUROD2","RBFOX1",
                                        "GAD1","PDE4DIP",
                                        "GFAP","AQP4","SLCO1C1"),
                           pt.size=0.08)
list_Anno<- list(C0="Excitatory Neurons",C1="Internuerons",C2="NPCs",C3="Excitatory Neurons",C4="Excitatory Neurons",C5="Astrocytes",C6="Excitatory Neurons",C7="OPCs",C8="Microglia")

pdf("VlnPlot_Key_Gene.pdf",width = 12,height = 9)
plot(VlnPlot_Key_Gene)
dev.off()

meta.data.Serat<- pbmc@meta.data
meta.data.Serat$Cell<- rownames(meta.data.Serat)
meta.data.Serat$seurat_clusters<- paste("C",meta.data.Serat$seurat_clusters,sep = "")

Cluster.Anno<- as.data.frame(t(as.data.frame(list_Anno)))
Cluster.Anno$seurat_clusters<- rownames(Cluster.Anno)
colnames(Cluster.Anno)[1]<- "CellType"

Clusmeta.data.Serat.out<- merge(meta.data.Serat,Cluster.Anno,by="seurat_clusters",all=T)
dim(Clusmeta.data.Serat.out)
rownames(Clusmeta.data.Serat.out)<- Clusmeta.data.Serat.out$Cell
write.table(Clusmeta.data.Serat.out,file = "meta.data.Serat.Cluster.txt",col.names = T,row.names = T,sep = "\t",quote = F)


# visualize key markers
VlnPlot(pbmc, features = c("PAX6", "PTPRC"), slot = "counts", log = TRUE)
FeaturePlot(pbmc, features = c("PAX6",
                               "PTPRC",
                               "PDGFRA",
                               "GAD1",
                               "AQP4",
                               "NEUROD2",
                               "OLIG1"))

# DoHeatmap() generates an expression heatmap for given cells and features. In this case, we are plotting the top 20 markers (or all markers if less than 20) for each cluster.
top10 <- pbmc.markers %>% group_by(cluster) %>% top_n(n = 50, wt = avg_log2FC)

pdf("Figure.X.DoHeatmap.pdf",width = 14,height = 10)
DoHeatmap(pbmc, features = top10$gene)# + NoLegend()
dev.off()


# Assigning cell type identity to clusters
pbmc2<- pbmc
new.cluster.ids <- as.character(list_Anno)
names(new.cluster.ids) <- levels(pbmc2)
pbmc2 <- RenameIdents(pbmc2, new.cluster.ids)

DimPlot.do<- DimPlot(pbmc2, reduction = "umap", label = TRUE, pt.size = 0.5) + NoLegend()


pdf("Figure.UMAP.Subtype.With.Annotation.pdf",width = 5,height = 4)
plot(DimPlot.do)# + NoLegend()
dev.off()



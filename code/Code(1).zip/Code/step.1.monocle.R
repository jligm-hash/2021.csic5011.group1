setwd("./")
library("monocle3")

# rows are genes, and columns are cells
pbmc.data <- read.table("GSE104276_all_pfc_2394_UMI_TPM_NOERCC.xls",header = T,sep = "\t",row.names = 1)
# rows are cells, and columns are cell attributes
cell_metadata1<- read.table("cell_mapping.txt",header = T,sep = "\t",row.names = 1)
dim(cell_metadata1)
cell_metadata<- read.table("./meta.data.Serat.Cluster.txt",header = T,sep = "\t",row.names = 1)

CellS<- intersect(rownames(cell_metadata1),colnames(pbmc.data))

expression_matrix<- pbmc.data[,CellS]
dim(expression_matrix)
cell_metadata<- cell_metadata[CellS,]
dim(cell_metadata)


gene_annotation<- data.frame(Gene=rownames(expression_matrix))
rownames(gene_annotation)<- rownames(expression_matrix)
gene_annotation$gene_short_name<- gene_annotation$Gene

cds <- new_cell_data_set(as.matrix(expression_matrix),
                         cell_metadata = cell_metadata,
                         gene_metadata = gene_annotation)

cds <- preprocess_cds(cds, num_dim = 50)


# Reduce dimensionality and visualize the results
cds <- reduce_dimension(cds,reduction_method="UMAP")
plot_cells(cds, label_groups_by_cluster=T,  color_cells_by = "cell_types")
plot_cells(cds, label_groups_by_cluster=T,  color_cells_by = "week")

cds <- cluster_cells(cds,reduction_method="UMAP")
plot_cells(cds, color_cells_by = "partition")

## learn_graph
cds <- learn_graph(cds)
UMAP_by_cell_types<- plot_cells(cds,
           color_cells_by = "cell_types",
           label_groups_by_cluster=T,
           label_leaves=FALSE,
           label_branch_points=FALSE)
pdf("UMAP.color_cells_by_cell_types.Author.pdf",width = 4,height = 4)
plot(UMAP_by_cell_types)
dev.off()


UMAP_by_week<- plot_cells(cds,reduction_method="UMAP",
           color_cells_by = "week",
           label_groups_by_cluster=T,
           label_leaves=F,
           label_branch_points=FALSE)
UMAP_by_week
pdf("UMAP.color_cells_by_week.pdf",width = 4,height = 4)
plot(UMAP_by_week)
dev.off()


####   add all week lable
UMAP_by_week_All<- plot_cells(cds,reduction_method="UMAP",
                          color_cells_by = "week",
                          label_groups_by_cluster=F,
                          label_leaves=F,
                          label_branch_points=FALSE)

UMAP_by_week_All
pdf("UMAP.color_cells_by_week_ALL.pdf",width = 4,height = 4)
plot(UMAP_by_week_All)
dev.off()


# Order the cells in pseudotime and determined the starting point
cds <- order_cells(cds)
plot_by_pseudotime<- plot_cells(cds,
           color_cells_by = "pseudotime",
           label_cell_groups=FALSE,
           label_leaves=FALSE,
           label_branch_points=FALSE,
           graph_label_size=1.5)
pdf("UMAP.color_by_pseudotime.pdf",width = 5,height = 4)
plot(plot_by_pseudotime)
dev.off()


plot_by_pseudotime<- plot_cells(cds,
                                color_cells_by = "CellType",
                                label_cell_groups=T,
                                label_leaves=FALSE,
                                label_branch_points=FALSE,
                                graph_label_size=1.5)
pdf("UMAP.color_by_MyCellType.pdf",width = 4,height = 4)
plot(plot_by_pseudotime)
dev.off()


traj.coord<- cds@principal_graph_aux@listData[["UMAP"]][["pseudotime"]]
traj.coord.d<- as.data.frame(traj.coord)
write.table(traj.coord.d,file = "pseudotime.txt",row.names = T,col.names = T,sep = "\t",quote = F)


# plot expression across trajactory
ciliated_genes <- c("PAX6",
                    "PTPRC",
                    "PDGRFA",
                    "GAD1",
                    "AQP4",
                    "NEUROD2",
                    "OLIG1")
important_distribution<- plot_cells(cds,
           genes=ciliated_genes,
           label_cell_groups=F,
           show_trajectory_graph=F)
pdf("UMAP.Selected.Genes.Distribution.pdf",width = 7,height = 4)
plot(important_distribution)
dev.off()

### Apendix
### Method used to extract cell expression data
markers<- gene_annotation$gene_short_name
markers_rowData <- rowData(cds)[(rowData(cds)$gene_short_name %in% markers) | (row.names(rowData(cds)) %in% markers),, drop = FALSE]
cds_exprs <- SingleCellExperiment::counts(cds)[row.names(markers_rowData), 
                                               , drop = FALSE]
cds_exprs <- Matrix::t(Matrix::t(cds_exprs)/size_factors(cds))
cds_exprs@x = round(10000 * cds_exprs@x)/10000
markers_exprs = matrix(cds_exprs, nrow = nrow(markers_rowData))
colnames(markers_exprs) = colnames(SingleCellExperiment::counts(cds))
row.names(markers_exprs) = row.names(markers_rowData)
write.csv(markers_exprs,file = "markers_exprs.csv")



